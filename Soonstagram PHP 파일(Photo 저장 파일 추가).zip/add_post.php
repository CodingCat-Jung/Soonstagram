<!-- add_post.php : 게시물 추가 기능 로직 / 폼
게시물 작성 - 내용, 사진(이미지는 크기와 형식 제한, 존재 여부 - 업로드 가능 여부 확인하는 변수) -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // 로그인 페이지로 리디렉션
    exit(); // 스크립트 실행 중지
}

$user_id = $_SESSION['user_id']; // 현재 로그인된 사용자 ID를 변수에 저장

// 게시물 업로드 처리
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_post'])) {
    $description = $_POST['description']; // 게시물 설명 가져오기
    $photo = $_FILES['photo']; // 업로드된 사진 파일 정보 가져오기

    // 사진 파일 업로드 처리
    $target_dir = "photo/"; // 파일을 저장할 디렉토리
    $imageFileType = strtolower(pathinfo($photo['name'], PATHINFO_EXTENSION)); // 파일 확장자 소문자로 변환
    $target_file = $target_dir . time() . '.' . $imageFileType; // 파일 이름에 타임스탬프 추가하여 고유한 파일명 생성
    $uploadOk = 1; // 파일 업로드 가능 여부를 나타내는 변수 초기화

    // 실제 이미지 파일인지 확인
    if(isset($_POST["submit_post"])) {
        $check = getimagesize($photo["tmp_name"]); // 업로드된 파일의 이미지 크기 및 형식 확인
        if($check !== false) {
            echo "File is an image - " . $check["mime"] . "."; // 파일이 이미지 파일임을 출력
            $uploadOk = 1; // 파일 업로드 가능
        } else {
            echo "File is not an image."; // 파일이 이미지 파일이 아님을 출력
            $uploadOk = 0; // 파일 업로드 불가
        }
    }

    // 파일 존재 확인
    if (file_exists($target_file)) {
        echo "Sorry, file already exists."; // 파일이 이미 존재함을 출력
        $uploadOk = 0; // 파일 업로드 불가
    }

    // 파일 크기 제한
    if ($photo["size"] > 5000000) { // 파일 크기가 5MB를 초과하는 경우
        echo "Sorry, your file is too large."; // 파일 크기가 너무 큼을 출력
        $uploadOk = 0; // 파일 업로드 불가
    }

    // 허용되는 파일 형식 제한
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed."; // 허용되지 않는 파일 형식임을 출력
        $uploadOk = 0; // 파일 업로드 불가
    }

    // 오류 검사
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded."; // 파일 업로드가 불가함을 출력
    // 파일 업로드 시도
    } else {
        if (move_uploaded_file($photo["tmp_name"], $target_file)) { // 파일 업로드 시도
            // DB에 게시물 정보 저장
            $stmt = $pdo->prepare("INSERT INTO posts (user_id, description, photo) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $description, $target_file]); // 게시물 정보를 데이터베이스에 저장
            echo "The file ". htmlspecialchars( basename( $photo["name"])). " has been uploaded."; // 업로드 성공 메시지 출력
            header("Location: profile.php?user_id=$user_id"); // 프로필 페이지로 리디렉션
            exit(); // 스크립트 실행 중지
        } else {
            echo "Sorry, there was an error uploading your file."; // 파일 업로드 중 오류 발생 시 출력
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Post</title>
</head>
<body>
    <h1>Add New Post</h1>
    <form action="add_post.php" method="post" enctype="multipart/form-data">
        Description: <textarea name="description" required></textarea><br> <!-- 설명 입력 필드 -->
        Photo: <input type="file" name="photo" required><br> <!-- 사진 업로드 필드 -->
        <input type="submit" name="submit_post" value="Upload Post"> <!-- 게시물 업로드 버튼 -->
    </form>
    <a href="profile.php?user_id=<?= $_SESSION['user_id'] ?>">Back to Profile</a> <!-- 프로필로 돌아가기 링크 -->
</body>
</html>
