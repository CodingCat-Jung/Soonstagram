<!-- sign_up.php : 회원가입 폼 / 로직 처리
1. 데이터베이스 연결
2. 데이터 입력받고 데이터 처리
3. 데이터베이스에 내용 추가 - SQL 쿼리 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함

$message = ''; // 사용자에게 보여줄 메시지를 저장할 변수 초기화

// 폼이 제출되었는지 확인
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // 폼에서 입력된 값들을 변수에 저장
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $student_id = $_POST['student_id'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // 비밀번호를 해시 처리

    // 사용자 정보를 데이터베이스에 삽입하는 SQL 쿼리
    $sql = "INSERT INTO SoonstagramUsers (name, gender, age, student_id, username, password) VALUES (?, ?, ?, ?, ?, ?)";

    try {
        $stmt = $pdo->prepare($sql); // SQL 쿼리를 준비
        $stmt->execute([$name, $gender, $age, $student_id, $username, $password]); // 입력된 값들을 바인딩하여 쿼리 실행
        $message = "회원가입 성공! 크루가 되신 것을 축하드립니다!"; // 성공 메시지 설정
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage(); // 오류 발생 시 오류 메시지 설정
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>Soonstagram에 오신 것을 환영합니다!</title> <!-- 페이지 제목 설정 -->
</head>
<body>
    <h2>Soonstagram의 크루가 되시겠습니까?</h2> <!-- 페이지 헤딩 -->
    <p><?php echo $message; ?></p> <!-- PHP 변수를 사용하여 메시지 출력 -->
    <form action="sign_up.php" method="post"> <!-- 회원가입 폼 -->
        Name: <input type="text" name="name" required><br> <!-- 이름 입력 필드 -->
        Gender: <input type="text" name="gender" required><br> <!-- 성별 입력 필드 -->
        Age: <input type="number" name="age" required><br> <!-- 나이 입력 필드 -->
        Student ID: <input type="text" name="student_id" required><br> <!-- 학번 입력 필드 -->
        Username: <input type="text" name="username" required><br> <!-- 사용자 이름 입력 필드 -->
        Password: <input type="password" name="password" required><br> <!-- 비밀번호 입력 필드 -->
        <input type="submit" name="submit" value="가입하기"> <!-- 가입하기 버튼 -->
    </form>
    <button onclick="window.location.href='main.php';">로그인 하기</button> <!-- 로그인 화면으로 이동 버튼 -->
</body>
</html>
