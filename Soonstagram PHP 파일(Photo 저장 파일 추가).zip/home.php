<!-- home.php : 로그인 후 홈 화면
1. 데이터베이스 연결 및 세션 시작
2. 로그인 여부 확인 후
3. 팔로워의 게시물 가져와 표시하고
4. 내 프로필 입장 버튼과 로그아웃 버튼 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 로그인 여부 확인
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php"); // 로그인하지 않은 경우 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

$user_id = $_SESSION['user_id']; // 세션에서 사용자 ID를 가져오기

// 팔로워의 게시물 가져오기
$posts_stmt = $pdo->prepare("SELECT p.id, p.photo, p.description, u.username, 
                             (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS likes_count, 
                             (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) AS user_liked 
                             FROM posts p 
                             JOIN follows f ON p.user_id = f.followed_id 
                             JOIN SoonstagramUsers u ON p.user_id = u.id 
                             WHERE f.follower_id = ? 
                             LIMIT 9");
$posts_stmt->execute([$user_id, $user_id]); // 현재 사용자의 ID를 바인딩하여 쿼리 실행
$posts = $posts_stmt->fetchAll(PDO::FETCH_ASSOC); // 쿼리 결과를 배열로 가져오기

// 댓글 추가 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $comment = htmlspecialchars($_POST['comment']); // 댓글 내용을 가져와서 HTML 특수문자를 변환
    $post_id = intval($_POST['post_id']); // 게시물 ID를 정수로 변환
    $user_id = $_SESSION['user_id']; // 세션에서 사용자 ID를 가져오기
    
    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)"); // 댓글을 데이터베이스에 삽입하는 쿼리 준비
    $stmt->execute([$post_id, $user_id, $comment]); // 댓글 정보를 바인딩하여 쿼리 실행
    
    header("Location: home.php"); // 댓글 추가 후 홈 페이지로 리디렉션
    exit(); // 스크립트 종료
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>Home</title> <!-- 페이지 제목 설정 -->
    <style>
        .grid {
            display: grid; /* 그리드 레이아웃 사용 */
            grid-template-columns: repeat(3, 1fr); /* 3열 그리드 */
            grid-gap: 10px; /* 그리드 사이의 간격 */
        }
        .grid img {
            width: 300px; /* 고정 너비 설정 */
            height: 350px; /* 고정 높이 설정 */
            object-fit: cover; /* 이미지가 요소 크기에 맞게 조절 */
        }
        header {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            justify-content: space-between; /* 헤더 요소를 좌우로 분리 */
            align-items: center; /* 세로 중앙 정렬 */
            padding: 20px; /* 패딩 설정 */
        }
        .post-item {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            flex-direction: column; /* 세로 방향으로 정렬 */
            align-items: flex-start; /* 왼쪽 정렬 */
        }
        .post-footer {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            align-items: center; /* 세로 중앙 정렬 */
            justify-content: space-between; /* 좌우로 분리 */
            width: 100%; /* 너비를 부모 요소에 맞춤 */
        }
        .likes-container {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            align-items: center; /* 세로 중앙 정렬 */
        }
        .likes-container p {
            margin-right: 10px; /* 좋아요 수와 버튼 사이의 간격 */
        }
        .comments-section {
            margin-top: 20px; /* 상단 여백 설정 */
        }
        .comment-item {
            margin-bottom: 10px; /* 하단 여백 설정 */
        }
    </style>
</head>
<body>
    <header>
        <h1>Soonstagram</h1>
        <div>
            <button onclick="window.location.href='profile.php';">View Profile</button> <!-- 프로필 페이지로 이동하는 버튼 -->
            <button onclick="window.location.href='logout.php';">Logout</button> <!-- 로그아웃 버튼 추가 -->
        </div>
    </header>
    <div class="grid">
        <?php foreach ($posts as $post): ?> <!-- 각 게시물에 대해 반복 -->
            <div class="post-item">
                <img src="<?= htmlspecialchars($post['photo']) ?>" alt="Post Image"> <!-- 게시물 사진 출력 -->
                <p><?= htmlspecialchars($post['username']) ?></p> <!-- 작성자 이름 출력 -->
                <p><?= htmlspecialchars($post['description']) ?></p> <!-- 게시물 설명 출력 -->
                <div class="post-footer">
                    <div class="likes-container">
                        <p>좋아요: <?= $post['likes_count'] ?></p> <!-- 좋아요 수 출력 -->
                        <?php if ($post['user_liked']): ?> <!-- 사용자가 좋아요를 눌렀는지 확인 -->
                            <button onclick="location.href='like_post.php?post_id=<?= $post['id'] ?>'">좋아요 취소</button>
                        <?php else: ?>
                            <button onclick="location.href='like_post.php?post_id=<?= $post['id'] ?>'">좋아요</button>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- 댓글 섹션 -->
                <div class="comments-section">
                    <form action="home.php" method="post"> <!-- 댓글 폼 -->
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>"> <!-- 게시물 ID를 숨겨서 전달 -->
                        <textarea name="comment" rows="2" cols="50" placeholder="댓글을 입력하세요..." required></textarea> <!-- 댓글 입력 필드 -->
                        <input type="submit" name="add_comment" value="댓글 달기"> <!-- 댓글 달기 버튼 -->
                    </form>
                    <?php
                    // 해당 게시물의 댓글 가져오기
                    $comments_stmt = $pdo->prepare("SELECT c.id, c.comment, u.username, c.user_id FROM comments c JOIN SoonstagramUsers u ON c.user_id = u.id WHERE c.post_id = ?");
                    $comments_stmt->execute([$post['id']]); // 현재 게시물 ID를 바인딩하여 쿼리 실행
                    $comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC); // 쿼리 결과를 배열로 가져온다
                    ?>
                    <?php foreach ($comments as $comment): ?> <!-- 각 댓글에 대해 반복 -->
                        <div class="comment-item">
                            <strong><?= htmlspecialchars($comment['username']) ?>:</strong> <?= htmlspecialchars($comment['comment']) ?>
                            <?php if ($comment['user_id'] == $_SESSION['user_id']): ?> <!-- 현재 사용자가 작성한 댓글인지 확인 -->
                                <a href="edit_comment.php?comment_id=<?= $comment['id'] ?>">수정</a>
                                <a href="delete_comment.php?comment_id=<?= $comment['id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?')">삭제</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
