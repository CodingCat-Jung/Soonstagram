<!-- edit_comment.php : 댓글 수정 폼 / 로직
comment_id를 이용해 사용자와 작성자 비교
본인이 작성한 댓글의 경우 수정 가능 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 사용자 로그인 여부 확인
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php"); // 로그인하지 않은 경우 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

$comment_id = isset($_GET['comment_id']) ? $_GET['comment_id'] : null; // URL에서 comment_id 가져오기

// comment_id가 없으면 오류 메시지 출력
if (!$comment_id) {
    echo "잘못된 접근입니다.";
    exit(); // 스크립트 종료
}

// 댓글 정보를 가져오는 쿼리 실행
$stmt = $pdo->prepare("SELECT * FROM comments WHERE id = ?");
$stmt->execute([$comment_id]); // comment_id를 바인딩하여 쿼리 실행
$comment = $stmt->fetch(); // 쿼리 결과를 가져온다

// 댓글이 없거나 사용자가 댓글의 작성자가 아닌 경우
if (!$comment || $comment['user_id'] != $_SESSION['user_id']) {
    echo "해당 댓글을 수정할 권한이 없습니다.";
    exit(); // 스크립트 종료
}

// 폼이 제출된 경우 댓글 업데이트 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updated_comment = htmlspecialchars($_POST['comment']); // 댓글 내용을 가져와서 HTML 특수문자를 변환
    $stmt = $pdo->prepare("UPDATE comments SET comment = ? WHERE id = ?"); // 댓글을 업데이트하는 쿼리
    $stmt->execute([$updated_comment, $comment_id]); // 업데이트할 값을 바인딩하여 쿼리 실행
    
    // 수정 후 이전 페이지로 돌아간다
    header("Location: " . $_SERVER['HTTP_REFERER']); // HTTP_REFERER 헤더를 사용하여 이전 페이지로 리디렉션
    exit(); // 스크립트 종료
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>댓글 수정</title> <!-- 페이지 제목 설정 -->
</head>
<body>
    <h1>댓글 수정</h1> <!-- 페이지 제목 -->
    <form action="edit_comment.php?comment_id=<?= $comment_id ?>" method="post"> <!-- 댓글 수정 폼 -->
        <textarea name="comment" rows="4" cols="50" required><?= htmlspecialchars($comment['comment']) ?></textarea><br> <!-- 댓글 입력 필드 -->
        <input type="submit" value="수정"> <!-- 수정 버튼 -->
    </form>
    <button onclick="window.history.back();">이전 화면으로</button> <!-- 이전 화면으로 돌아가는 버튼 -->
</body>
</html>
