<!-- edit_post.php : 게시물 수정, 삭제 로직 / 폼
1. post_id를 이용하여 본인 인증 및 권한 확인 
2. 작성자가 본인인 경우 수정 및 삭제 가능 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 사용자가 로그인되지 않은 경우 메인 페이지로 리디렉션
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php"); // 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

// URL에서 post_id를 가져옴
$post_id = isset($_GET['post_id']) ? $_GET['post_id'] : null;

// post_id가 제공되지 않은 경우 에러 메시지 출력
if (!$post_id) {
    echo "잘못된 접근입니다.";
    exit(); // 스크립트 종료
}

// post_id로 게시물을 가져오는 SQL 쿼리 준비 및 실행
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

// 게시물이 없거나 게시물이 현재 사용자에 의해 작성되지 않은 경우 에러 메시지 출력
if (!$post || $post['user_id'] != $_SESSION['user_id']) {
    echo "해당 게시물을 수정할 권한이 없습니다.";
    exit(); // 스크립트 종료
}

// POST 요청이 들어오면 업데이트 또는 삭제 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete_post'])) {
        // 게시글과 관련된 좋아요 및 댓글 삭제
        $delete_likes = $pdo->prepare("DELETE FROM likes WHERE post_id = ?");
        $delete_likes->execute([$post_id]);

        $delete_comments = $pdo->prepare("DELETE FROM comments WHERE post_id = ?");
        $delete_comments->execute([$post_id]);

        // 게시글 삭제
        $delete_post = $pdo->prepare("DELETE FROM posts WHERE id = ?");
        $delete_post->execute([$post_id]);

        // 게시글 삭제 후 프로필 페이지로 리디렉션
        header("Location: profile.php?user_id=" . $_SESSION['user_id']);
        exit(); // 스크립트 종료
    } else {
        $description = $_POST['description']; // 게시물 설명을 가져온다

        // 사진 파일이 업로드된 경우 처리
        if (!empty($_FILES['photo']['name'])) {
            $target_dir = "photo/"; // 사진을 저장할 디렉토리
            $target_file = $target_dir . basename($_FILES["photo"]["name"]); // 사진의 전체 경로
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION)); // 사진 파일의 확장자
            $valid_extensions = array("jpg", "jpeg", "png", "gif"); // 허용되는 확장자

            if (in_array($imageFileType, $valid_extensions)) {
                if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                    // 업로드된 새 사진의 경로를 업데이트
                    $stmt = $pdo->prepare("UPDATE posts SET photo = ?, description = ? WHERE id = ?");
                    $stmt->execute([$target_file, $description, $post_id]);
                } else {
                    echo "사진 업로드 중 오류가 발생했습니다.";
                }
            } else {
                echo "유효하지 않은 파일 형식입니다. jpg, jpeg, png, gif 파일만 허용됩니다.";
            }
        } else {
            // 사진을 변경하지 않는 경우 설명만 업데이트
            $stmt = $pdo->prepare("UPDATE posts SET description = ? WHERE id = ?");
            $stmt->execute([$description, $post_id]);
        }

        // 업데이트 후 프로필 페이지로 리디렉션
        header("Location: profile.php?user_id=" . $_SESSION['user_id']);
        exit(); // 스크립트 종료
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>게시물 수정</title> <!-- 페이지 제목 설정 -->
</head>
<body>
    <h1>게시물 수정</h1> <!-- 페이지 제목 -->
    <!-- 게시물 수정 폼 -->
    <form action="edit_post.php?post_id=<?= $post_id ?>" method="post" enctype="multipart/form-data">
        <label for="photo">사진:</label><br>
        <img src="<?= htmlspecialchars($post['photo']) ?>" alt="Current Photo" style="width:300px;height:auto;"><br> <!-- 현재 사진 표시 -->
        <input type="file" name="photo" id="photo"><br><br> <!-- 새 사진 업로드 입력 -->
        <label for="description">설명:</label><br>
        <textarea name="description" id="description" rows="4" cols="50"><?= htmlspecialchars($post['description']) ?></textarea><br> <!-- 설명 입력 -->
        <input type="submit" value="수정"> <!-- 수정 버튼 -->
    </form>
    <!-- 게시물 삭제 폼 -->
    <form action="edit_post.php?post_id=<?= $post_id ?>" method="post" onsubmit="return confirm('정말 삭제하시겠습니까?');">
        <input type="hidden" name="delete_post" value="1"> <!-- 삭제를 위한 숨겨진 필드 -->
        <input type="submit" value="삭제"> <!-- 삭제 버튼 -->
    </form>
    <button onclick="window.location.href='profile.php?user_id=<?= $_SESSION['user_id'] ?>';">프로필로 돌아가기</button> <!-- 프로필 페이지로 돌아가는 버튼 -->
</body>
</html>
