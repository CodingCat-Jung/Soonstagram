<!-- following.php : 팔로잉 목록 가져오는 로직 / 폼
데이터베이스에서 팔로잉 목록을 가져와 표시해줌  - SQL문

+ 리스트에서 이름 클릭하면 그 사람의 프로필로 입장할 수 있는 기능 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// URL에서 user_id가 제공되지 않은 경우 메인 페이지로 리디렉션
if (!isset($_GET['user_id'])) {
    header("Location: main.php"); // 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

$user_id = $_GET['user_id']; // URL에서 user_id를 가져온다
// 팔로잉 목록을 가져오는 SQL 쿼리 준비 및 실행
$stmt = $pdo->prepare("SELECT u.id, u.username FROM SoonstagramUsers u JOIN follows f ON u.id = f.followed_id WHERE f.follower_id = ?");
$stmt->execute([$user_id]); // user_id를 바인딩하여 쿼리 실행
$followings = $stmt->fetchAll(PDO::FETCH_ASSOC); // 결과를 배열로 가져온다
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>팔로잉 목록</title> <!-- 페이지 제목 설정 -->
</head>
<body>
    <h1>팔로잉 목록</h1> <!-- 페이지 제목 -->
    <ul>
        <?php foreach ($followings as $following): ?> <!-- 팔로잉 목록을 반복하면서 표시 -->
            <li><a href="profile.php?user_id=<?= htmlspecialchars($following['id']) ?>"><?= htmlspecialchars($following['username']) ?></a></li> <!-- 팔로잉 사용자의 프로필 링크 -->
        <?php endforeach; ?>
    </ul>
    <a href="profile.php">프로필로 돌아가기</a> <!-- 프로필 페이지로 돌아가는 링크 -->
</body>
</html>
