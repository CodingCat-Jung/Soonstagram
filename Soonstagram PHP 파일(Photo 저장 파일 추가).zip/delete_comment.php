<!-- delete_comment.php : 댓글 삭제 로직
comment_id를 이용해 사용자와 작성자 비교
본인이 작성한 댓글의 경우 삭제 가능 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 사용자 로그인 여부 확인
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php"); // 로그인하지 않은 경우 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

$comment_id = isset($_GET['comment_id']) ? $_GET['comment_id'] : null; // URL에서 comment_id 가져오기
if (!$comment_id) { // comment_id가 없으면
    echo "잘못된 접근입니다."; // 오류 메시지 출력
    exit(); // 스크립트 종료
}

// 댓글 정보를 가져오는 쿼리 실행
$stmt = $pdo->prepare("SELECT * FROM comments WHERE id = ?");
$stmt->execute([$comment_id]); // comment_id를 바인딩하여 쿼리 실행
$comment = $stmt->fetch(); // 쿼리 결과를 가지고 온다

// 댓글이 없거나 사용자가 댓글의 작성자가 아닌 경우
if (!$comment || $comment['user_id'] != $_SESSION['user_id']) {
    echo "해당 댓글을 삭제할 권한이 없습니다."; // 오류 메시지 출력
    exit(); // 스크립트 종료
}

// 댓글을 삭제하는 쿼리 실행
$stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
$stmt->execute([$comment_id]); // comment_id를 바인딩하여 쿼리 실행

// 삭제 후 이전 페이지로 돌아감
header("Location: " . $_SERVER['HTTP_REFERER']); // HTTP_REFERER 헤더를 사용하여 이전 페이지로 리디렉션
exit(); // 스크립트 종료
?>
