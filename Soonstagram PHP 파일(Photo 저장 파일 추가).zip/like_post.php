<!-- like_post.php : 좋아요 기능 로직
1. 현재 사용자의 ID를 가져와서 현재 사용자와 게시물 사이의 좋아요 상태를 확인 - 좋아요를 이미 눌렀는지
1-1. 이미 눌렀으면 좋아요 취소
1-2. 아직 안 눌렀으면 좋아요 추가 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 사용자가 로그인되지 않은 경우 메인 페이지로 리디렉션
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php"); // 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

$user_id = $_SESSION['user_id']; // 현재 세션의 사용자 ID를 가져온다
$post_id = isset($_GET['post_id']) ? $_GET['post_id'] : null; // URL에서 post_id를 가져온다

// post_id가 제공되지 않은 경우 에러 메시지 출력
if (!$post_id) {
    echo "잘못된 접근입니다.";
    exit(); // 스크립트 종료
}

// 좋아요 상태 확인
$stmt = $pdo->prepare("SELECT * FROM likes WHERE user_id = ? AND post_id = ?"); // 좋아요 상태를 확인하는 SQL 쿼리
$stmt->execute([$user_id, $post_id]); // 쿼리를 실행하고 현재 사용자와 게시물의 좋아요 상태를 확인
$like = $stmt->fetch(); // 결과를 가져온다

if ($like) {
    // 좋아요가 이미 있는 경우 좋아요 취소
    $stmt = $pdo->prepare("DELETE FROM likes WHERE user_id = ? AND post_id = ?"); // 좋아요를 삭제하는 SQL 쿼리
    $stmt->execute([$user_id, $post_id]); // 쿼리를 실행하여 좋아요를 삭제
} else {
    // 좋아요가 없는 경우 좋아요 추가
    $stmt = $pdo->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)"); // 좋아요를 추가하는 SQL 쿼리
    $stmt->execute([$user_id, $post_id]); // 쿼리를 실행하여 좋아요를 추가
}

// 이전 페이지로 리디렉션
header("Location: " . $_SERVER['HTTP_REFERER']); // 사용자를 이전 페이지로 리디렉션
exit(); // 스크립트 종료
?>
