<!-- login.php : 로그인 로직
1. 데이터 베이스 연결
2. 사용자 입력 내용 가져오기 - 아이디, 비밀번호
3. 사용자 정보 조회 / 비밀번호 체크
3-1. 검증 성공시 세션에 사용자ID 저장하고 홈페이지로 리디렉션
3-2. 실패시 오류 메세지 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

$username = $_POST['username']; // 폼에서 입력된 사용자 이름을 가져오기
$password = $_POST['password']; // 폼에서 입력된 비밀번호를 가져오기

$sql = "SELECT * FROM SoonstagramUsers WHERE username = ?"; // 사용자 이름을 기준으로 사용자 정보를 가져오는 SQL 쿼리
$stmt = $pdo->prepare($sql); // SQL 쿼리를 준비
$stmt->execute([$username]); // 사용자 이름을 바인딩하고 실행
$user = $stmt->fetch(); // 쿼리 결과를 가지고 온다

// 사용자가 존재하고 비밀번호가 일치하는지 확인
if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id']; // 세션에 사용자 ID를 저장
    header("Location: home.php"); // 로그인 성공 시 홈 페이지로 리디렉션
} else {
    echo "Invalid username or password"; // 로그인 실패 시 오류 메시지 출력
}
?>
