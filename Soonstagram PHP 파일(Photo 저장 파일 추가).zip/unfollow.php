<!-- unfollow.php : 언팔로우 로직
1. 팔로우 할 유저의 ID를 받고 팔로우 관계 확인 후 데이터베이스에서 삭제
1-1. 정상적으로 삭제되면 종료
1-2. 에러 메세지 출력 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 팔로우를 해제할 사용자 ID 확인
if (isset($_GET['user_id'])) { // URL에서 user_id가 제공되었는지 확인
    $followed_id = $_GET['user_id']; // 팔로우를 해제할 사용자의 ID를 가져온다
    $follower_id = $_SESSION['user_id']; // 현재 로그인된 사용자의 ID를 세션에서 가져온다

    // 데이터베이스에서 팔로우 관계 삭제
    $stmt = $pdo->prepare("DELETE FROM follows WHERE follower_id = ? AND followed_id = ?"); // 팔로우 관계를 삭제하는 쿼리
    $stmt->execute([$follower_id, $followed_id]); // 팔로워와 팔로우된 사용자의 ID를 바인딩하여 쿼리 실행

    // 성공적으로 팔로우 해제되면, 사용자를 다시 프로필 페이지로 리다이렉트
    header("Location: profile.php?user_id=" . $followed_id); // 팔로우 해제된 사용자의 프로필 페이지로 리디렉트
    exit(); // 스크립트 종료
} else {
    // user_id가 제공되지 않은 경우 에러 메세지 출력
    echo "Invalid request."; // 잘못된 요청임을 알리는 메세지 출력
    exit(); // 스크립트 종료
}
?>
