<!-- SoonstagramDB.php : MySQL에서 데이터베이스 연결 로직
데이터베이스 서버 주소, 데이터베이스 이름, 사용자 이름, 사용자 비밀번호 설정
PDO 객체 생성 후 데이터베이스 연결
PDO 객체의 에러 모드를 설정하여 오류 발생 시 예외 처리 -->

<?php
$host = 'localhost'; // 데이터베이스 서버 주소
$dbname = 'Soonstagram'; // 사용할 데이터베이스 이름
$username = 'root'; // 데이터베이스 사용자 이름
$password = '0000'; // 사용자 비밀번호

try {
    // PDO 객체 생성 및 데이터베이스 연결
    // DSN(Data Source Name): 데이터베이스 서버와 데이터베이스 이름을 포함한 문자열
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // PDO 에러 모드를 예외로 설정
    // PDO::ERRMODE_EXCEPTION: 오류가 발생하면 PDOException을 던짐
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // echo "데이터베이스에 성공적으로 연결되었습니다."; // 연결 성공 메시지 출력 (테스트용)
} catch (PDOException $e) { // PDO 예외 처리
    // 에러 로그에 연결 오류 메시지를 기록
    // error_log 함수: 지정된 파일에 에러 메시지를 기록
    error_log("Connection error: " . $e->getMessage(), 3, "/path/to/error.log");
    
    // die 함수: 메시지를 출력하고 스크립트를 종료
    die("Connection failed: An error occurred."); // 사용자에게 보여주는 메시지를 일반화
}
?>
