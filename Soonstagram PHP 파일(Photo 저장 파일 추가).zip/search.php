<!-- search.php : 유저 검색 폼 / 로직
1. 사용자 검색
2. 존재 여부
2-1. 존재한다면 해당 사람의 프로필 내용 출력, 팔로우 관계 출력 - 팔로우 버튼 (이미 팔로우인 경우에는 팔로우 중 표시) -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 로그인된 사용자가 아니라면 로그인 페이지로 리디렉션
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit();
}

$user_id = $_SESSION['user_id']; // 현재 로그인된 사용자 ID
$search_username = isset($_POST['username']) ? $_POST['username'] : ''; // 검색할 사용자 이름
$search_user = null; // 검색된 사용자 정보를 저장할 변수 초기화
$follow_exists = false; // 팔로우 상태를 저장할 변수 초기화

// POST 요청인지와 검색할 사용자 이름이 있는지 확인
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($search_username)) {
    // 사용자 검색 쿼리 실행
    $stmt = $pdo->prepare("SELECT * FROM SoonstagramUsers WHERE username = ?");
    $stmt->execute([$search_username]);
    $search_user = $stmt->fetch(); // 검색된 사용자 정보 가져오기

    if ($search_user) {
        $search_user_id = $search_user['id']; // 검색된 사용자의 ID

        // 팔로우 관계가 존재하는지 확인
        $follow_check_stmt = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE follower_id = ? AND followed_id = ?");
        $follow_check_stmt->execute([$user_id, $search_user_id]);
        $follow_exists = $follow_check_stmt->fetchColumn() > 0;

        if ($follow_exists) {
            $message = "이미 팔로우 중입니다."; // 이미 팔로우 상태인 경우
        } else {
            // 팔로우 관계 추가
            $follow_stmt = $pdo->prepare("INSERT INTO follows (follower_id, followed_id) VALUES (?, ?)");
            $follow_stmt->execute([$user_id, $search_user_id]);
            $message = "팔로우 성공!"; // 팔로우 성공 메시지
        }
    } else {
        $message = "사용자를 찾을 수 없습니다."; // 사용자를 찾지 못한 경우 메시지
    }
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>사용자 검색</title>
</head>
<body>
    <h1>사용자 검색</h1>
    <!-- 사용자 검색 폼 -->
    <form action="search.php" method="post">
        <input type="text" name="username" placeholder="사용자 이름 입력" required>
        <input type="submit" value="검색">
    </form>
    <?php if ($search_user): ?>
        <h2>검색 결과:</h2>
        <p>이름: <?= htmlspecialchars($search_user['name']) ?></p>
        <p>사용자 이름: <?= htmlspecialchars($search_user['username']) ?></p>
        <?php if ($follow_exists): ?>
            <p>이미 팔로우 중입니다.</p>
        <?php else: ?>
            <!-- 팔로우 폼 -->
            <form action="search.php" method="post">
                <input type="hidden" name="username" value="<?= htmlspecialchars($search_user['username']) ?>">
                <input type="submit" value="팔로우">
            </form>
        <?php endif; ?>
    <?php elseif (isset($message)): ?>
        <p><?= $message ?></p>
    <?php endif; ?>
    <!-- 프로필 페이지로 돌아가는 버튼 -->
    <button onclick="window.location.href='profile.php?user_id=<?= $user_id ?>';">프로필로 돌아가기</button>
</body>
</html>
