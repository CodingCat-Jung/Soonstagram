<!-- profile.php : 자신의 프로필 화면 / 상대방 프로필 화면
** user_id를 이용해 본인 여부 확인

1. 나의 페이지인 경우
팔로워/ 팔로잉, 이름/ 나이 - 프로필 정보 업데이트 버튼, 게시물 추가, 유저 검색, 홈으로 돌아가는 버튼, 게시물 - 게시물 수정/ 삭제, 좋아요, 댓글

2. 상대방 페이지인 경우
팔로워/ 팔로잉, 이름/ 나이 - 업데이트 버튼 x, 되돌아 가는 버튼, 게시물 - 수정/ 삭제 x, 좋아요, 댓글

+ 팔로워, 팔로우 클릭 -> 목록에서 클릭으로 프로필 입장 기능 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// URL에서 user_id 받기 또는 현재 세션의 user_id 사용
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : $_SESSION['user_id'];

if (!isset($user_id)) {
    header("Location: main.php"); // user_id가 설정되지 않았으면 메인 페이지로 리디렉션
    exit(); // 스크립트 종료
}

// 프로필 업데이트 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = htmlspecialchars($_POST['name']); // 이름 입력값을 가져와서 HTML 특수문자를 변환
    $age = htmlspecialchars($_POST['age']); // 나이 입력값을 가져와서 HTML 특수문자를 변환
    
    // 업데이트 쿼리 실행
    $stmt = $pdo->prepare("UPDATE SoonstagramUsers SET name = ?, age = ? WHERE id = ?");
    $stmt->execute([$name, $age, $user_id]); // 업데이트할 값을 바인딩하여 쿼리 실행
    
    // 업데이트 후 새로고침
    header("Location: profile.php?user_id=" . $user_id);
    exit(); // 스크립트 종료
}

// 댓글 추가 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $comment = htmlspecialchars($_POST['comment']); // 댓글 내용을 가져와서 HTML 특수문자를 변환
    $post_id = intval($_POST['post_id']); // 게시물 ID를 정수로 변환
    $user_id = $_SESSION['user_id']; // 세션에서 사용자 ID를 가져온다
    
    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)"); // 댓글을 데이터베이스에 삽입하는 쿼리
    $stmt->execute([$post_id, $user_id, $comment]); // 댓글 정보를 바인딩하여 쿼리 실행
    
    // 댓글 추가 후 프로필 페이지로 리디렉션
    header("Location: profile.php?user_id=" . $user_id);
    exit(); // 스크립트 종료
}

// 사용자 정보 가져오기
$stmt = $pdo->prepare("SELECT * FROM SoonstagramUsers WHERE id = ?");
$stmt->execute([$user_id]); // user_id를 바인딩하여 쿼리 실행
$user = $stmt->fetch(); // 쿼리 결과를 가져온다

if (!$user) {
    echo "사용자 정보를 찾을 수 없습니다."; // 사용자 정보를 찾을 수 없을 때 메시지 출력
    exit(); // 스크립트 종료
}

// 팔로워 수 가져오기
$follower_count = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE followed_id = ?");
$follower_count->execute([$user_id]); // user_id를 바인딩하여 쿼리 실행
$follower_result = $follower_count->fetchColumn(); // 팔로워 수를 가져온다

// 팔로잉 수 가져오기
$following_count = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE follower_id = ?");
$following_count->execute([$user_id]); // user_id를 바인딩하여 쿼리 실행
$following_result = $following_count->fetchColumn(); // 팔로잉 수를 가져온다

// 게시글과 작성자 정보를 함께 가져오는 쿼리
$posts_stmt = $pdo->prepare("SELECT p.id, p.photo, p.description, u.username, 
                             (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS likes_count, 
                             (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) AS user_liked 
                             FROM posts p JOIN SoonstagramUsers u ON p.user_id = u.id 
                             WHERE p.user_id = ?");
$posts_stmt->execute([$_SESSION['user_id'], $user_id]); // 현재 사용자 ID와 프로필 사용자 ID를 바인딩하여 쿼리 실행
$posts = $posts_stmt->fetchAll(PDO::FETCH_ASSOC); // 쿼리 결과를 배열로 가지고 온다

// 팔로우 상태 확인
$is_following_stmt = $pdo->prepare("SELECT COUNT(*) FROM follows WHERE follower_id = ? AND followed_id = ?");
$is_following_stmt->execute([$_SESSION['user_id'], $user_id]); // 현재 사용자 ID와 프로필 사용자 ID를 바인딩하여 쿼리 실행
$is_following_result = $is_following_stmt->fetchColumn() > 0; // 팔로우 상태 확인

$is_own_profile = ($user_id == $_SESSION['user_id']); // 자신의 프로필인지 확인
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title><?= htmlspecialchars($user['username']) ?>'s Profile</title> <!-- 페이지 제목 설정 -->
    <style>
        body {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            margin: 0; /* 기본 마진 제거 */
            padding: 20px; /* 패딩 설정 */
            font-family: Arial, sans-serif; /* 폰트 설정 */
            background: #f4f4f4; /* 배경색 설정 */
        }
        .profile-sidebar {
            flex: 1; /* 플렉스박스 아이템 설정 */
            padding: 20px; /* 패딩 설정 */
            margin-right: 20px; /* 오른쪽 마진 설정 */
        }
        .posts-container {
            flex: 2; /* 플렉스박스 아이템 설정 */
            padding: 20px; /* 패딩 설정 */
            display: grid; /* 그리드 레이아웃 사용 */
            grid-template-columns: repeat(3, 1fr); /* 3열 그리드 */
            grid-gap: 10px; /* 그리드 아이템 간격 설정 */
        }
        .profile-sidebar::after {
            content: ""; /* 추가 콘텐츠 설정 */
            position: absolute; /* 절대 위치 설정 */
            right: 0; /* 오른쪽 정렬 */
            top: 0; /* 상단 정렬 */
            bottom: 0; /* 하단 정렬 */
            width: 1px; /* 너비 설정 */
            background-color: #ccc; /* 배경색 설정 */
        }
        .post-item {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            flex-direction: column; /* 세로 방향 정렬 */
            align-items: flex-start; /* 왼쪽 정렬 */
        }
        .post-image {
            width: 300px; /* 고정 너비 설정 */
            height: 350px; /* 고정 높이 설정 */
            object-fit: cover; /* 이미지가 요소 크기에 맞게 조절 */
        }
        .post-footer {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            align-items: center; /* 세로 중앙 정렬 */
            justify-content: space-between; /* 좌우로 분리 */
            width: 100%; /* 너비를 부모 요소에 맞춤 */
        }
        .likes-container {
            display: flex; /* 플렉스박스 레이아웃 사용 */
            align-items: center; /* 세로 중앙 정렬 */
        }
        .likes-container p {
            margin-right: 10px; /* 좋아요 수와 버튼 사이의 간격 */
        }
        form, .button-group {
            margin-top: 20px; /* 상단 여백 설정 */
        }
        button, input[type="submit"] {
            cursor: pointer; /* 마우스 포인터를 손가락 모양으로 변경 */
            padding: 10px 20px; /* 패딩 설정 */
            margin-right: 10px; /* 오른쪽 마진 설정 */
            background-color: #007BFF; /* 배경색 설정 */
            color: white; /* 글자색 설정 */
            border: none; /* 테두리 제거 */
            border-radius: 5px; /* 둥근 모서리 설정 */
            margin-bottom: 10px; /* 하단 마진 설정 */
        }
        button:hover, input[type="submit"]:hover {
            background-color: #0056b3; /* 호버 상태에서 배경색 변경 */
        }
        .comments-section {
            margin-top: 20px; /* 상단 여백 설정 */
        }
        .comment-item {
            margin-bottom: 10px; /* 하단 여백 설정 */
        }
        .profile-info p {
            display: inline-block; /* 인라인 블록 설정 */
            margin-right: 10px; /* 간격을 더 좁히기 위해 조정 */
        }
    </style>
</head>
<body>
    <div class="profile-sidebar">
        <h1><?= htmlspecialchars($user['username']) ?>'s Profile</h1> <!-- 사용자 이름 출력 -->
        <div class="profile-info">
            <p>팔로워: <a href="followers.php?user_id=<?= $user_id ?>"><?= $follower_result ?></a></p> <!-- 팔로워 수 출력 -->
            <p>팔로잉: <a href="following.php?user_id=<?= $user_id ?>"><?= $following_result ?></a></p> <!-- 팔로잉 수 출력 -->
        </div>

        <?php if (!$is_own_profile): ?> <!-- 자신의 프로필이 아닌 경우 -->
            <?php if ($is_following_result): ?> <!-- 팔로우 상태 확인 -->
                <button onclick="location.href='unfollow.php?user_id=<?= $user_id ?>'">팔로우 중</button> <!-- 팔로우 중인 경우 언팔로우 버튼 -->
            <?php else: ?>
                <button onclick="location.href='follow.php?user_id=<?= $user_id ?>'">팔로우</button> <!-- 팔로우하지 않은 경우 팔로우 버튼 -->
            <?php endif; ?>
            <p>이름: <?= htmlspecialchars($user['name']) ?></p> <!-- 사용자 이름 출력 -->
            <p>나이: <?= htmlspecialchars($user['age']) ?></p> <!-- 사용자 나이 출력 -->
        <?php else: ?> <!-- 자신의 프로필인 경우 -->
            <form action="profile.php?user_id=<?= $user_id ?>" method="post"> <!-- 프로필 업데이트 폼 -->
                이름: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required><br> <!-- 이름 입력 필드 -->
                나이: <input type="number" name="age" value="<?= htmlspecialchars($user['age']) ?>" required><br> <!-- 나이 입력 필드 -->
                <input type="submit" name="update_profile" value="프로필 업데이트"> <!-- 업데이트 버튼 -->
            </form>
            <div class="button-group">
                <button onclick="window.location.href='add_post.php';">게시물 추가</button> <!-- 게시물 추가 버튼 -->
            </div>
        <?php endif; ?>
        <div class="button-group">
            <button onclick="window.location.href='search.php';">유저 검색</button> <!-- 유저 검색 버튼 -->
            <button onclick="window.location.href='home.php';">홈</button> <!-- 홈 버튼 -->
        </div>
    </div>
    <div class="posts-container">
        <h2><?= $is_own_profile ? '내 게시물' : '게시물' ?></h2> <!-- 게시물 섹션 제목 -->
        <?php foreach ($posts as $post): ?> <!-- 각 게시물에 대해 반복 -->
            <div class="post-item">
                <?php if ($is_own_profile): ?> <!-- 자신의 프로필인 경우 -->
                    <a href="edit_post.php?post_id=<?= $post['id'] ?>"> <!-- 게시물 수정 링크 -->
                        <img src="<?= htmlspecialchars($post['photo']) ?>" alt="Post" class="post-image"> <!-- 게시물 사진 출력 -->
                        <p><?= htmlspecialchars($post['username']) ?></p> <!-- 게시물 작성자 출력 -->
                    </a>
                <?php else: ?> <!-- 자신의 프로필이 아닌 경우 -->
                    <img src="<?= htmlspecialchars($post['photo']) ?>" alt="Post" class="post-image"> <!-- 게시물 사진 출력 -->
                <?php endif; ?>
                <p><?= htmlspecialchars($post['description']) ?></p> <!-- 게시물 설명 출력 -->
                <div class="post-footer">
                    <div class="likes-container">
                        <p>좋아요: <?= $post['likes_count'] ?></p> <!-- 좋아요 수 출력 -->
                        <?php if ($post['user_liked']): ?> <!-- 사용자가 좋아요를 눌렀는지 확인 -->
                            <button onclick="location.href='like_post.php?post_id=<?= $post['id'] ?>'">좋아요 취소</button> <!-- 좋아요 취소 버튼 -->
                        <?php else: ?>
                            <button onclick="location.href='like_post.php?post_id=<?= $post['id'] ?>'">좋아요</button> <!-- 좋아요 버튼 -->
                        <?php endif; ?>
                    </div>
                </div>
                <!-- 댓글 섹션 -->
                <div class="comments-section">
                    <form action="profile.php?user_id=<?= $user_id ?>" method="post"> <!-- 댓글 폼 -->
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>"> <!-- 게시물 ID를 숨겨서 전달 -->
                        <textarea name="comment" rows="2" cols="50" placeholder="댓글을 입력하세요..." required></textarea> <!-- 댓글 입력 필드 -->
                        <input type="submit" name="add_comment" value="댓글 달기"> <!-- 댓글 달기 버튼 -->
                    </form>
                    <?php
                    // 해당 게시물의 댓글 가져오기
                    $comments_stmt = $pdo->prepare("SELECT c.id, c.comment, u.username, c.user_id FROM comments c JOIN SoonstagramUsers u ON c.user_id = u.id WHERE c.post_id = ?");
                    $comments_stmt->execute([$post['id']]); // 현재 게시물 ID를 바인딩하여 쿼리 실행
                    $comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC); // 쿼리 결과를 배열로 가져옴
                    ?>
                    <?php foreach ($comments as $comment): ?> <!-- 각 댓글에 대해 반복 -->
                        <div class="comment-item">
                            <strong><?= htmlspecialchars($comment['username']) ?>:</strong> <?= htmlspecialchars($comment['comment']) ?> <!-- 댓글 작성자와 내용 출력 -->
                            <?php if ($comment['user_id'] == $_SESSION['user_id']): ?> <!-- 현재 사용자가 작성한 댓글인지 확인 -->
                                <a href="edit_comment.php?comment_id=<?= $comment['id'] ?>">수정</a> <!-- 댓글 수정 링크 -->
                                <a href="delete_comment.php?comment_id=<?= $comment['id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?')">삭제</a> <!-- 댓글 삭제 링크 -->
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
