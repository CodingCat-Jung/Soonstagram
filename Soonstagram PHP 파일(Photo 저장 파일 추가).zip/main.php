<!-- main.php : 로그인하는 첫 화면  
0. 데이터베이스 연결 및 세션 시작
1. 로그인하는 첫 화면
1-1. 로그인 확인 후 입장
2. 회원가입 버튼 -->

<?php
require 'SoonstagramDB.php'; // 데이터베이스 연결 파일 포함
session_start(); // 세션 시작

// 로그인 폼이 제출되었는지 확인
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username']; // 폼에서 입력된 사용자 이름을 가져오기
    $password = $_POST['password']; // 폼에서 입력된 비밀번호를 가져오기

    // 사용자 이름을 기준으로 사용자 정보를 가져오는 SQL 쿼리 
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $pdo->prepare($sql); // SQL 쿼리를 준비
    $stmt->execute([$username]); // 사용자 이름을 바인딩하고 실행
    $user = $stmt->fetch(); // 쿼리 결과를 가져오기

    // 사용자가 존재하고 비밀번호가 일치하는지 확인
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id']; // 세션에 사용자 ID를 저장
        header("Location: home.php"); // 로그인 성공 시 홈 페이지로 리디렉션
        exit(); // 스크립트 종료
    } else {
        $message = "Invalid username or password"; // 로그인 실패 시 오류 메시지 설정
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- 문서의 문자 인코딩을 설정 -->
    <title>Welcome to Soonstagram</title> <!-- 페이지 제목 설정 -->
    <style>
        body {
            display: flex; /* flexbox 레이아웃 사용 */
            justify-content: center; /* 수평 중앙 정렬 */
            align-items: center; /* 수직 중앙 정렬 */
            height: 100vh; /* 뷰포트 높이를 100%로 설정 */
            margin: 0; /* 기본 마진 제거 */
            background: #f4f4f4; /* 배경색 설정 */
            font-family: Arial, sans-serif; /* 폰트 설정 */
        }

        .login-container {
            background: white; /* 배경색을 흰색으로 설정 */
            padding: 20px; /* 내부 여백 설정 */
            border-radius: 8px; /* 둥근 모서리 설정 */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* 박스 그림자 설정 */
            text-align: center; /* 텍스트 중앙 정렬 */
            width: 300px; /* 너비 설정 */
        }

        input[type="text"],
        input[type="password"] {
            width: 200px; /* 입력 필드 너비 설정 */
            padding: 10px; /* 내부 여백 설정 */
            margin: 10px 0; /* 상하 여백 설정 */
            border: 1px solid #ddd; /* 테두리 설정 */
            border-radius: 4px; /* 둥근 모서리 설정 */
        }

        input[type="submit"],
        button {
            width: 100%; /* 버튼 너비를 부모 요소에 맞춤 */
            padding: 10px; /* 내부 여백 설정 */
            border: none; /* 테두리 제거 */
            background-color: #5C67F2; /* 배경색 설정 */
            color: white; /* 글자색 설정 */
            border-radius: 4px; /* 둥근 모서리 설정 */
            cursor: pointer; /* 마우스 포인터를 손가락 모양으로 변경 */
            margin-top: 10px; /* 상단 마진 설정 */
        }

        input[type="submit"]:hover,
        button:hover {
            background-color: #4a54e1; /* 호버 상태에서 배경색 변경 */
        }

        h3 {
            margin: 0; /* 기본 마진 제거 */
            color: #333; /* 글자색 설정 */
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h3>Soonstagram</h3> <!-- 사이트 제목 -->
        <form action="login.php" method="post"> <!-- 로그인 폼 -->
            Username: <input type="text" name="username" required> <!-- 사용자 이름 입력 필드 -->
            Password: <input type="password" name="password" required> <!-- 비밀번호 입력 필드 -->
            <input type="submit" name="login" value="Login"> <!-- 로그인 버튼 -->
        </form>
        <button onclick="window.location.href='sign_up.php';">Sign Up</button> <!-- 회원가입 페이지로 이동 버튼 -->
    </div>
</body>
</html>
